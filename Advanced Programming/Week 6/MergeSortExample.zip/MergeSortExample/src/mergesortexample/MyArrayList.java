/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mergesortexample;
import java.util.*;
/**
 *
 * @author cmuntean
 */

public class MyArrayList<ElemType> extends ArrayList<ElemType>
{
     
    public void mergeSort(int start, int end)
    {
        int mid = 0;
        if (start < end)
        {
            mid=(start+end)/2;   // mid in the middle between start and end is determined
            mergeSort (start, mid);  //first part of the array (from start to mid) sorted by recursive calls
            mergeSort (mid+1, end); //second part of the array (from mid+1 to end) sorted by recursive calls	merge(array, start, mid, end);
            merge(start, mid, end); // merges array [start .. mid] with array[mid+1.. end]
        }
        else // do nothing, the array has one element, so it is sorted
           return;
     }

    public void merge (int left, int middle, int right)
    {
        int i=left;
        int j=middle+1;
        int k = 0;
        ArrayList <Object> tempArray = new ArrayList <Object>();

        while (i <= middle && j <= right)
        {
            if( ((Comparable)get(i)).compareTo((Comparable)get(j))< 0 )
            {
                tempArray.add(k,get(i));
                i=i+1;
            }
            else
            {
               tempArray.add(k,get(j));
               j=j+1;
            }
            k=k+1;
        }
   
        while (i<=middle)
        {      // there are elems left in 1st half to be copied
          tempArray.add(k,get(i));
          k=k+1;
          i=i+1;
        }

        while ( j<= right)
        {          // there are elems left in 2nd half to be copied           
           tempArray.add(k,get(j));
           k=k+1;
           j=j+1;
        }

        
        for ( i=left, k=0; i<=right; i++, k++)      // copy the sorted tempArray into the original array
            set(i,(ElemType)tempArray.get(k));
    }


}
