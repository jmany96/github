/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package revision_exercise4;

/**
 *
 * @author cmuntean
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //TASKS TO DO
        //declare and create an MyArrayList object.
        //Add some number into your MyArrayList type object
        // call CountNOTMovedElements_InsertionSort() method and check if it works correct
    }
}
