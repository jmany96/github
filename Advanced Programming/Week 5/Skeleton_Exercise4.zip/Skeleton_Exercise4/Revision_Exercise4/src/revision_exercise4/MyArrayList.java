/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package revision_exercise4;
import java.util.*;
/**
 *
 * @author cmuntean
 */
public class MyArrayList<ElemType> extends ArrayList<ElemType>
{
     // this is a relatively efficient bubble sort ( as bubble sorts go ). It recognises that after each
    // pass of the outer loop an additional rightmost element is in the correct position and can be ignored
   
   public void insertionSort()
    {
        int i;
        int pos;
        Comparable keyelement;
        for (i = 1; i< size();i++)
        {
            keyelement = (Comparable)get(i);
            pos = i;  //position of the key element

            while (pos > 0 && ((Comparable)get(pos-1)).compareTo(keyelement) >0)
            {
                ElemType elemPosMinusOne = get(pos-1);
                set(pos, elemPosMinusOne);
                pos = pos -1;
            } //end while loop

            set(pos,(ElemType)keyelement); //insert the key element in the correct position
        }
  }    

   
   //TASK TO DO
   
   //write the implementation of the CountNOTMovedElements_InsertionSort()  method that 
   //sorts the elements in ascendant order and  
    // counts and returns how many elements WERE NOT removed from their initial location 
 
     
 
}

