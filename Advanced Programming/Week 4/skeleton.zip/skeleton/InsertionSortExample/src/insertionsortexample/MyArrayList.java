/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package insertionsortexample;
import java.util.*;
/**
 *
 * @author cmuntean
 */
public class MyArrayList<ElemType> extends ArrayList<ElemType>
{
     // this is a relatively efficient bubble sort ( as bubble sorts go ). It recognises that after each
    // pass of the outer loop an additional rightmost element is in the correct position and can be ignored
    public void bubbleSort()
    {
       int i,j;
       Comparable  elemAtJ,elemAtJPlus;
       for (i=0; i < size(); i++ )
       {

	  for (j=0; j < size()-1 -i ; j++ )
	  {
              elemAtJ = (Comparable)get(j);
              elemAtJPlus = (Comparable)get(j+1);

	      if (elemAtJ.compareTo(elemAtJPlus) > 0)
	      {
		//swap element on postion j with element on position j+1
                  swap(j, j+1);
	      }
           }
       }
     }

     public void swap(int pos1, int pos2)
     {
         ElemType objPos1 = get(pos1);
         ElemType objPos2 = get(pos2);

         remove(pos1);
         add(pos1, objPos2);
         remove(pos2);
         add(pos2, objPos1);
    }

   public void insertionSort()
    {
       /*
        * Write the Java code for the insertionSort() method based on the pseudo code provided in the notes.
        */
  }    
}

