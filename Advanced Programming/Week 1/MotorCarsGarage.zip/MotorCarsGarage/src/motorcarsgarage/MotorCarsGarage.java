/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package motorcarsgarage;

/**
 *
 * @author cmuntean
 */
public class MotorCarsGarage {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("MotorCarsGarage");
        System.out.println("10, Drumcondra Road, Dubin 5");
        System.out.println("Phone: 563400");
        
        // write your code here
	   // create one object Car type
	   //set the model, color and year of the Car object
	   // print the details of the Car objecr

    }
}
