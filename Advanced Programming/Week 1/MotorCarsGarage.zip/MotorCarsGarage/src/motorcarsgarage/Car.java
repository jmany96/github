/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package motorcarsgarage;

/**
 *
 * @author cmuntean
 */
public class Car {
public String model; 
public String color;   
public int year;

 public Car (String inModel, String inColor, int inYear)
    {
        // write your code here
    }

public String getModel()   
{
    // write your code here
    return "";
}
public void setModel(String inModel)
{
    // write your code here
}
public String getColor()   
{
    // write your code here
    return "";
}
public void setColor(String inColor)
{
    // write your code here
}
public int getYear()
{
    // write your code here
    return -1;
}
public void setYear(int inYear)  
{
    // write your code here
}
public void printCar()
{
    // write your code here
}

    
}
