/* Database Script File */

/* Created by Eamon Nolan */

/* Date Created: 18-Sep-2016 */

/* Last Update Date:    */

/* Updated By:      */

/* Update Content ?  */


/* Script Starts here */

/* Database stuff */

DROP DATABASE videos;

CREATE DATABASE videos;

USE videos;

/* Table Scripts */

DROP TABLE customers;

CREATE TABLE customers
(
	cust_id	INTEGER,
	cust_name VARCHAR(25),
	cust_addr_1 VARCHAR(10),
	cust_address VARCHAR(50),
	cust_county_id INTEGER,
	PRIMARY KEY (cust_id));

DROP TABLE counties;
	
CREATE TABLE counties
(
	county_id INTEGER,
	county_name VARCHAR(20),
	province_id INTEGER,
	PRIMARY KEY (county_id));
	
DROP TABLE provinces;
	
CREATE TABLE provinces
(
	province_id INTEGER,
	province_name VARCHAR(20),
	PRIMARY KEY (province_id));
	
DROP TABLE orders;
	
CREATE TABLE orders
(
	ord_id	INTEGER NOT NULL AUTO_INCREMENT,
	cust_id INTEGER,
	ord_date DATE,
	PRIMARY KEY (ord_id));
	
DROP TABLE order_details;
	
CREATE TABLE order_details
(
	item_id INTEGER,
	ord_id	INTEGER,
	vid_id INTEGER,
	qty INTEGER,
	vid_price DECIMAL(7,2),
	date_rent_out DATE,
	date_returned DATE,
	PRIMARY KEY (ord_id, item_id));

DROP TABLE videos;
	
CREATE TABLE videos
(
	vid_id	INTEGER,
	vid_name VARCHAR(25),
	vid_purchase_price DECIMAL(7,2),
	vid_rental_cost DECIMAL(7,2),
	qty_in_stock INTEGER,
	rental_length_days INTEGER,
	PRIMARY KEY (vid_id));


/* Insert records into provinces table here */

INSERT INTO provinces
(province_id, province_name )
VALUES
( 1, 'Ulster'),
( 2, 'Leinster'),
( 3, 'Connaught'),
( 4, 'Munster');


/* Insert records into the counties table here */

INSERT INTO counties
(county_id, county_name, province_id )
VALUES
( 1, 'Antrim',1),
( 2, 'Armagh', 1),
( 3, 'Cavan', 1),
( 4, 'Donegal', 1),
( 5, 'Down', 1),
( 6, 'Derry', 1),
( 7, 'Fermanagh', 1),
( 8, 'Monaghan', 1),
( 9, 'Tyrone', 1),
( 10, 'Carlow', 2),
( 11, 'Kilkenny', 2),
( 12, 'Kildare', 2),
( 13, 'Dublin', 2),
( 14, 'Laois', 2),
( 15, 'Westmeath', 2),
( 16, 'Meath', 2),
( 17, 'Wicklow', 2),
( 18, 'Louth', 2),
( 19, 'Offaly', 2),
( 20, 'Wexford', 2),
( 21, 'Longford', 2),
( 22, 'Clare',3),
( 23, 'Galway', 3),
( 24,'Mayo', 3),
( 25, 'Sligo', 3),
( 26, 'Roscommon', 3),
( 27, 'Kerry', 4),
( 28, 'Waterford', 4),
( 29, 'Cork', 4),
( 30, 'Tipperary', 4),
( 31, 'Limerick', 4),
( 32, 'Clare', 4);



/* Insert records into contacts table here */

INSERT INTO customers
(cust_id, cust_name, cust_addr_1, cust_address, cust_county_id)
VALUES
( 1, 'EMC Videos Distributors', 15, 'Blancharstown Lane Dublin 2', 12),
( 2, 'John Burke', 17,  'Tempers Avenue Dublin 12', 12),
( 3, 'John Flanagan', 5,  'Murray Avenue Dublin 5', 12),
( 4, 'Wayne Himself', 15, 'NCI Dublin 2', 12),
( 5, 'Eamon Somebody', 21, 'NCI Dublin 2', 12);


/* Insert records into videos table here */

INSERT INTO videos
(vid_id, vid_name, vid_purchase_price, vid_rental_cost, qty_in_stock, rental_length_days)
VALUES
( 1, 'The Matrix', '40.25', '2.50', 50, 21), 
( 2, '12 Years a Slave', '50.25', '3.50', 80, 21),
( 3, 'Captain Philips', '30.25', '1.50', 75, 28),
( 4, 'Wolf on Wall Street', '20.25', '1.50', 70, 21),
( 5, 'Batman Returns', '45.25', '2.50', 60, 21), 
( 6, 'Two Tulips', '10.25', '3.50', 80, 21);

/* Insert records into Orders table here */

INSERT INTO orders
(ord_id, cust_id, ord_date)
VALUES
( 1, 1, '2013/10/29'),
( 2, 2, '2013/11/10'),
( 3, 2, '2013/11/11'),
( 4, 2, '2013/11/12'),
( 5, 1, '2013/11/15'),
( 6, 3, '2013/11/20');

/* Insert records into Order Details table here */

INSERT INTO order_details
(item_id, ord_id, vid_id, qty, vid_price, date_rent_out, date_returned)
VALUES
( 1, 1, 1, 50, '40.25', '2014/10/21', NULL),
( 2, 1, 2, 80, '50.25', '2014/10/21', NULL),
( 3, 1, 3, 75, '30.25', '2014/10/21', NULL),
( 4, 1, 4, 70, '20.25', '2014/10/21', NULL),
( 5, 1, 5, 60, '45.25', '2014/10/21', NULL),
( 6, 1, 6, 80, '10.25', '2014/10/21', NULL),
( 1, 2, 1, 2, '42.50', '2013/11/22', NULL),
( 2, 2, 2, 4, '3.50', '2013/11/22', NULL),
( 3, 2, 3, 5, '1.50','2013/11/22', NULL),
( 1, 3, 1, 2, '42.50', '2013/11/23', NULL),
( 2, 3, 2, 4, '3.50', '2013/11/23', NULL),
( 3, 3, 3, 5, '1.50', '2013/11/23', '2013/11/25'),
( 1, 4, 4, 2, '42.50', '2013/11/24', NULL),
( 2, 4, 4, 4, '3.50', '2013/11/24', NULL),
( 3, 4, 4, 5, '1.50', '2013/11/24', '2013/11/26');

/*  Some Select Statements */

SELECT * FROM Videos;

SELECT 		c.cust_id ID, 
			c.cust_name Name, 
			c.cust_addr_1 Street,
			c.cust_address as Address
FROM		customers c;


SELECT		o.ord_date "Date", 
			o.ord_id "Order No",
			c.cust_name "Name",
			v.vid_name "Video Name",
			od.qty "Qty Rented",
			od.date_rent_out "Rented On",
			od.date_returned "Returned"
FROM		orders o
INNER JOIN	order_details od
ON			o.ord_id = od.ord_id
INNER JOIN	videos v
ON			od.vid_id = v.vid_id
INNER JOIN	customers c
ON			c.cust_id = o.cust_id;