﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace If_Else_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            int result;

            Console.WriteLine("Please enter marks between 0 and 100:");
            result = int.Parse(Console.ReadLine());

            if (result >= 60)
                Console.WriteLine("Passed");
            else
                Console.WriteLine("Failed");
           
            Console.ReadLine();
        }
    }
}
