﻿using System;
using System.Collections.Generic;


namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World");
            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }
    }
}
