﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "Anu";
            int marks = 100;
            Console.WriteLine("Name: " + name + " got " + marks + " marks");

            Console.WriteLine("Please enter a new name");
            name = Console.ReadLine();

            Console.WriteLine("Please enter marks");
            marks = int.Parse(Console.ReadLine());

            Console.WriteLine("Name: " + name + " got " + marks + " marks");

            Console.ReadLine();


        }
    }
}
